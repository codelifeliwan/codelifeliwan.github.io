/*
 * main.c
 *
 *  Created on: Sep 25, 2012
 *      Author: wanli
 */
#include"yeelink.h"

int main()
{
	return 0;
}
